package Test_Practice;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

public class B extends A {

	@BeforeMethod
	public void module3() {
		
		System.out.println("This is module 3");
	}
	
}
