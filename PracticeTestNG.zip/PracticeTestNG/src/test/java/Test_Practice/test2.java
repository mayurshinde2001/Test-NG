package Test_Practice;

import org.testng.annotations.Test;

public class test2 {

	
	@Test(priority = 0)
	public void ACB() {
		System.out.println("Test case B");
	}
	@Test(priority = -1)
	public void BCS() {
		System.out.println("Test case A");
	}
	@Test(priority = -2)
	public void AAA() {
		System.out.println("Test case C");
	}
	@Test(priority = -3)
	public void ABC() {
		System.out.println("Test case D");
	}
}
