package Test_Practice;

import org.testng.annotations.Test;
import org.testng.annotations.AfterMethod;

public class AfterMethods {

	
	@AfterMethod
	public void A() {
		System.out.println("Test case A");
	}
	
	@Test
	public void B() {
		System.out.println("Test case B");
	}
}
