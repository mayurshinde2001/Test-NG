package Test_Practice;

import org.testng.annotations.Test;

public class A {

	@Test
	public void module1() {
		System.out.println("This is module 1");
	}
	
	@Test
	public void module2() {
		
		System.out.println("This is module 2");
	}
}
