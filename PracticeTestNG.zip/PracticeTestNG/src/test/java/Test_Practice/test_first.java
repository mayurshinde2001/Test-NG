package Test_Practice;



import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class test_first {

	
     
		
		@Test
		public void LoginFunctionality() {
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.facebook.com/");
		driver.manage().window().maximize();
		WebElement name=driver.findElement(By.id("email"));
		name.sendKeys("4616542346");
		WebElement pass=driver.findElement(By.id("pass"));
		pass.sendKeys("46416868798");
		driver.findElement(By.name("login")).click();
	}
		
		@Test
		public void VerifyTitle() {
			WebDriver driver=new ChromeDriver();
			driver.get("https://www.facebook.com/");
			driver.manage().window().maximize();
			String title=driver.getTitle();
			System.out.println(title);
		}
	
}
