package Test_Practice;

import org.testng.annotations.Test;

public class practicemethod {

	@Test(dependsOnMethods = {"D","C"})
	public void A() {
		System.out.println("this is A");
	}
	
	@Test
	public void B() {
		System.out.println("this is B");
	}

	@Test
	public void C() {
		System.out.println("this is C");
	}

	@Test
	public void D() {
		System.out.println("this is D");
	}

}
