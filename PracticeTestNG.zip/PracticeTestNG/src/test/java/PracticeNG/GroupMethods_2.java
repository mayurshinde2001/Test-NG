package PracticeNG;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class GroupMethods_2 {

	
	@Test(groups = "smoke")
	public void VerifyTitle1() {
	
		WebDriver driver=new ChromeDriver();
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		String title=driver.getTitle();
		System.out.println(title);
	}
	
	
	@Test(groups = "functional")
	public void VerifyURL() {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		String URL=driver.getCurrentUrl();
		System.out.println(URL);
	}
	
	@Test(groups = "regression")
	public void VerifyPageID() {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		String ID=driver.getWindowHandle();
		System.out.println(ID);
	}
	
	
	@Test(groups = "smoke")
	public void VerifyPageSource() {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		String source=driver.getPageSource();
		System.err.println(source);
	}
}
