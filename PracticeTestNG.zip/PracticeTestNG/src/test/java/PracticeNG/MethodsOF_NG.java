package PracticeNG;

import java.security.PublicKey;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

public class MethodsOF_NG {

	
	
	@Test
	public void LoginFB() {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.facebook.com/");
		
		Actions act=new Actions(driver);
		
		WebElement username=driver.findElement(By.id("email"));
		username.sendKeys("7378746346");
		
		act.keyDown(Keys.TAB).sendKeys("992246154").keyUp(Keys.TAB)
		.keyDown(Keys.ENTER).build().perform();
		
		
		
	}
	
	@AfterMethod
	public void VerifyTitle() {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.facebook.com/");
		String title=driver.getTitle();
		System.out.println(title);
	}
	
	@Test
	public void PageID() {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.facebook.com/");
		String id=driver.getWindowHandle();
		System.out.println(id);
		
	}
	
	@Test
	public void PageURL() {
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.facebook.com/");
		String url=driver.getCurrentUrl();
		System.out.println(url);
	}
}
