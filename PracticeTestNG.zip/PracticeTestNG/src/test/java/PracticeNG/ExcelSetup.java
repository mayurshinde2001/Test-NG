package PracticeNG;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class ExcelSetup {

	
	public FileInputStream file;
	public XSSFWorkbook workbook;
	public XSSFSheet sheet;
	public XSSFRow row;
	public XSSFCell cell;
	
	
	@Test
	public int rowcount(String sheetname, String path ) throws IOException {
		
		File f1=new File(path);
		
		file=new FileInputStream(f1);
		
		workbook= new XSSFWorkbook(file);
		
		sheet=workbook.getSheet(sheetname);
		
		int rowcount=sheet.getLastRowNum();
		
		workbook.close();
		file.close();
		
		return rowcount;
}
	@Test
	public int columncount(String sheetname,String path) throws IOException {
		
		File f1=new File(path);
		
		file= new FileInputStream(f1);
		
		workbook= new XSSFWorkbook(file);
		
		sheet=workbook.getSheet(sheetname);
		
		int columncount=row.getLastCellNum();
		workbook.close();
		file.close();
		
		return columncount;
		
	}
	
	
	@Test
	public String getcellvalue(String path, String sheetname, int rownum, int cellnum) throws IOException {
		
		File f1=new File(path);
		file=new FileInputStream(f1);
		workbook=new XSSFWorkbook(file);
		sheet=workbook.getSheet(sheetname);
		row=sheet.getRow(rownum);
		cell=row.getCell(cellnum);
		String data="";
		
		try {
		DataFormatter format=new DataFormatter();
		
		data=format.formatCellValue(cell);
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
		}
		workbook.close();
		file.close();
		
		return data;
		
	}
	
	
}
