package PracticeNG;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class GroupMethods {

	
	@Test(groups = "smoke")
	public void VerifyTitle() {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.facebook.com/");
		
		String title=driver.getTitle();
		System.out.println(title);
	}
	
	@Test(groups = "regression")
	public void VerifyURL() {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.facebook.com/");
		
		String URL=driver.getCurrentUrl();
		System.out.println(URL);
	}
	
	@Test(groups = "smoke")
	public void VerifyPageID() {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.facebook.com/");
		
		String ID=driver.getWindowHandle();
		System.out.println(ID);
	}
}
