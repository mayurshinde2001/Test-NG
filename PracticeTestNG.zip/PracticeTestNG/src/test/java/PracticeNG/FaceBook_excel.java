package PracticeNG;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;


@Test(dataProvider = "datalist")
public class FaceBook_excel {

	public WebDriver driver;
	
	
	public void FbLogin(String username,String pass) {
		
		driver=new ChromeDriver();
		
		driver.get("https://www.facebook.com/");
		
		driver.findElement(By.id("email")).sendKeys(username);
		driver.findElement(By.id("pass")).sendKeys(pass);
		driver.findElement(By.name("login")).click();
	}
	
	
	@DataProvider(name="datalist")
	public String[][] test() throws IOException{
		
		ExcelSetup xl=new ExcelSetup();
		
		String path="C:\\Users\\Lenovo\\eclipse-workspace\\PracticeTestNG\\src\\test\\java\\TestData\\FBData.xlsx";
		
		String sheetname="FBSheet";
		
		int rowcount=xl.rowcount(sheetname, path);
		int columncount=xl.columncount(sheetname, path);
		
		String[][] data=new String[rowcount][columncount];
		
		for(int i=0;i<=rowcount;i++) {
			for(int j=0;j<=columncount;j++) {
				data[i-1][j]=xl.getcellvalue(path, sheetname, i, j);
			}
		}
		
		return data;
		
	}
}
