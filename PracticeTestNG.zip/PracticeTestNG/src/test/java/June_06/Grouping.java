package June_06;

import org.testng.annotations.Test;

public class Grouping {

	
	@Test(groups = {"smoke"})
	public void test1() {
		
		System.out.println("TEst first");
	}
	
	@Test(groups = {"regression"})
	public void test2() {
		
		System.out.println("TEst 2nd");
	}

	
	@Test(groups = {"regression"})
	public void test3() {
	
	System.out.println("TEst 3rd");
}

	
	@Test(groups = {"smoke"})
	public void test4() {
	
	System.out.println("TEst 4th");
}
}
