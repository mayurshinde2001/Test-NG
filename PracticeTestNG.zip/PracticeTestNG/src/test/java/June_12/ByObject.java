package June_12;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class ByObject {
	
	
	@Test
	public void FBLogin() {
		WebDriver driver= new ChromeDriver();
		
		driver.get("https://www.facebook.com/");
		
		By username=By.id("email");
		By pass=By.id("pass");
		By login=By.name("login");
		By error=By.xpath("//div[@class='_9ay7']");
		
		
		driver.findElement(username);
		driver.findElement(pass);
		driver.findElement(login).click();
		
		
		WebElement text=driver.findElement(error);
		
		String ActualMsg=text.getText();
		
		//String ExpectedMsg="The email address or mobile number you entered isn't connected to an account";
		
		if(ActualMsg.contains("email")) {
			
			Assert.assertTrue(true);
			System.out.println("TEst Case Passed...");
		}
		else {
			Assert.assertTrue(false);
			System.out.println("Test case failed..");
		}
		
		
		
		
		
		
	}
}
