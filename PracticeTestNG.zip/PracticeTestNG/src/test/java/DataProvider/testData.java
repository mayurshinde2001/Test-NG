package DataProvider;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class testData {

	
	@Parameters({"username","pass"})
	@Test(dataProvider = "credential")
	public void Login(String username,String pass) throws InterruptedException {
		
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver.manage().window().maximize();
		
		Thread.sleep(2000);
		driver.findElement(By.xpath(" //input[@name='username']")).sendKeys(username);
		
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@name='password']")).sendKeys(pass);
		
		driver.findElement(By.xpath("//button[@type='submit']")).click();
	}
	
	
	@DataProvider(name = "credential")
	public Object[][]abc(){
		return new Object[][] {
			
			
			{"nsjfou","admin123"},  //valid data
			{"abkjdbs","nxhjscan"}  //invalid data
		
		
		};
		
	}
	
	
}
