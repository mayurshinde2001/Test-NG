package DataProvider;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class OrangeHRM {

	
	
	

	@Parameters({"username","pass"})
	@Test(dataProvider = "Data")
	public void Login(String username,String pass,String Data) throws InterruptedException {
		
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver.manage().window().maximize();
		
		Thread.sleep(2000);
		driver.findElement(By.xpath(" //input[@name='username']")).sendKeys(username);
		
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@name='password']")).sendKeys(pass);
		
		driver.findElement(By.xpath("//button[@type='submit']")).click();
		
		if(Data.equals("Valid")) {
			String Ar=driver.getTitle();
			System.out.println(Ar);
			String ER="OrangeHRM";
			
			Assert.assertEquals(Ar, ER);
			
			System.out.println("Login Successfull....");
		}
			else {
				System.out.println("Invalid data");
			}
		
	}

	
	@DataProvider(name = "Data")
	public Object[][]function(){
		return new Object[][] {
			
			
			{"Admin","admin123","Valid"},  //valid data
			{"abkjdbs","nxhjscan","Invalid"},  //invalid data
		
		
		};
		
		
	}
	

}