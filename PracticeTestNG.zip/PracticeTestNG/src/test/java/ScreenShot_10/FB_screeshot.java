package ScreenShot_10;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class FB_screeshot {

  public WebDriver driver;
	@Test
	public void FBLOgin() throws IOException {
		
		 driver=new ChromeDriver();
		driver.get("https://www.facebook.com/");
		driver.manage().window().maximize();
		
		String path="C:\\Users\\Lenovo\\eclipse-workspace\\PracticeTestNG\\src\\test\\java\\ScreenShot_File\\abcd.png";
		
		GetScreenShot(driver,path);
	}
	
	public void GetScreenShot(WebDriver driver,String path) throws IOException {
		
		TakesScreenshot tc=(TakesScreenshot)driver;
		
		File sourcefile=tc.getScreenshotAs(OutputType.FILE);
		
		//String path="C:\\Users\\Lenovo\\eclipse-workspace\\PracticeTestNG\\src\\test\\java\\ScreenShot_File\\abcd.png";
		
		File DestinationFile=new File(path);
		
		FileUtils.copyFile(sourcefile, DestinationFile);
	}
	
}
