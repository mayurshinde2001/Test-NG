package TestCases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import pages.loginpage;

public class FirstTestCase {

	@Test
	public void loginFbTest() {
	
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.facebook.com/");
		driver.manage().window().maximize();
		
		loginpage log=new loginpage(driver);
		
//		WebElement username=log.getUsername();
//		username.sendKeys("abc@123");
//		
//		WebElement password=log.getPassword();
//		password.sendKeys("abc123");
//		
//		WebElement login=log.getLogin();
//		login.click();
		
		
		log.sendusername("akcouua");
		log.sendpass("gdw7gbjsd");
 		log.clickonLogin();
		
	}
}
