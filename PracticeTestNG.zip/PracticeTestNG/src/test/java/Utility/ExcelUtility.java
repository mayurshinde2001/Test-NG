package Utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.Test;

public class ExcelUtility {

	public FileInputStream file;
	public XSSFWorkbook workbook;
	public XSSFSheet sheet;
	public XSSFRow row;
	public XSSFCell cell;

	// public String
	// path="C:\\Users\\Lenovo\\eclipse-workspace\\PracticeTestNG\\src\\test\\java\\TestData\\SetOf
	// Data.xlsx";

	@Test
	public int rowCount(String sheetname, String path) throws IOException {

		File f1 = new File(path);
		file = new FileInputStream(f1);

		workbook = new XSSFWorkbook(file);

		sheet = workbook.getSheet(sheetname);

		int rowcount = sheet.getLastRowNum();

		workbook.close();
		file.close();

		return rowcount;

	}

	@Test
	public int coloumncount(String sheetname, String path) throws IOException {
		File f1 = new File(path);
		file = new FileInputStream(f1);

		workbook = new XSSFWorkbook(file);

		sheet = workbook.getSheet(sheetname);

		//row = sheet.getRow(0);

		int columncount = row.getLastCellNum();

		workbook.close();
		file.close();

		return columncount;

	}

	public String getCellValue(String sheetname, String path, int rownum, int cellnum) throws IOException {

		File f1 = new File(path);
		file = new FileInputStream(f1);

		workbook = new XSSFWorkbook(file);

		sheet = workbook.getSheet(sheetname);

		row = sheet.getRow(rownum);

		cell = row.getCell(cellnum);

		String data = "";
		try {

			DataFormatter format = new DataFormatter();

			data = format.formatCellValue(cell);

		} catch (Exception e) {

			System.out.println(e.getMessage());
		}
		workbook.close();
		file.close();

		return data;

	}
}
