package Utility;

public class marksProvider {

	public static void main(String[] args) {
		
		
		a obj=new a();
		
		obj.sagar(135, 70);
	}
	
}
