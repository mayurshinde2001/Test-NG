package Utility;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class TestUtility {

	
	
	
	@Test(dataProvider = "Datatest")
	public void hrmlogin(String username,String pass,String data) throws InterruptedException {
		WebDriver driver=new ChromeDriver();
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver.manage().window().maximize();
		
		Thread.sleep(2000);
		driver.findElement(By.xpath(" //input[@name='username']")).sendKeys(username);
		
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@name='password']")).sendKeys(pass);
		
		driver.findElement(By.xpath("//button[@type='submit']")).click();
		
		
		
	}
	
	@DataProvider(name="Datatest")
	public String[][] test() throws IOException {
		ExcelUtility xl = new ExcelUtility();

		String path = "C:\\Users\\Lenovo\\eclipse-workspace\\PracticeTestNG\\src\\test\\java\\TestData\\SetOf Data.xlsx";

		String sheetname = "credentials";

		int rowCount = xl.rowCount(sheetname, path);

		int columnCount = xl.coloumncount(sheetname, path);

//		String data = xl.getCellValue(sheetname, path, 2, 2);
//
//		System.out.println("CellValue=" + data);
//
//		System.out.println("Rows=" + rowCount);
//
//		System.out.println("coloumns=" + columnCount);
		
		
		String [][] data=new String[rowCount][columnCount];
		
		for(int i=1;i<=rowCount;i++) {
			for(int j=0;j<columnCount;j++) {
				
				data[i-1][j]=xl.getCellValue(sheetname, path, i, j);
			}
		}
		
		//System.out.println(data[1][1]);
		return data;
	}
}
