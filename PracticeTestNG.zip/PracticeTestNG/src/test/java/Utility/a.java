package Utility;

public class a {

	
	public void sagar(int value,int value2) {
		
		
		System.out.println("JAva Score"+value);
		
		System.out.println("Manual Score"+value2);
	}
}
