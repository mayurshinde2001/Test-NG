package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class loginpage {

	public WebDriver getDriver() {
		return driver;
	}


	public WebElement getUsername() {
		return username;
	}



	public WebElement getPassword() {
		return password;
	}



	public WebElement getLogin() {
		return login;
	}
	
	
	
	
	
	
	public WebDriver driver;
	
	public loginpage(WebDriver driver) {
		
		this.driver=driver;
		
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(id = "email")
	private WebElement username;
	
	
	@FindBy(id="pass")
	private WebElement password;
	
	
	@FindBy(name="login")
	private WebElement login;
	
	
	
	//send keys
	public void sendusername(String user) {
		username.sendKeys(user);
	}
	
	public void sendpass(String pass) {
		password.sendKeys(pass);
	}
	
	public void clickonLogin() {
		login.click();;
	}
	
	
	public void sendkeys(String username,String password) {
	
		
		
}
}
