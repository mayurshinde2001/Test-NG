package June_07;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class verificationusingTestNG {

	@Parameters({"username","pass"})
	@Test
	public void LoginTitle( String username, String pass) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		
		Thread.sleep(2000);
		driver.findElement(By.xpath(" //input[@name='username']")).sendKeys(username);
		driver.findElement(By.xpath("//input[@name='password']")).sendKeys(pass);
		
		driver.findElement(By.xpath("//button[@type='submit']")).click();
		
		String title=driver.getTitle();
		System.out.println(title);
		
		if(title.equalsIgnoreCase("OrangeHRM")) {
			System.out.println("Test Passed...!!");
		}
		else {
				System.out.println("Test Failed...!!!");
		}
		
	}
}
