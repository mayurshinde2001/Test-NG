package June_07;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class Assertion {

	public SoftAssert soft;
	
	@Parameters({"username","pass"})
	@Test
public void LoginTitle( String username, String pass) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		
		Thread.sleep(2000);
		driver.findElement(By.xpath(" //input[@name='username']")).sendKeys(username);
		driver.findElement(By.xpath("//input[@name='password']")).sendKeys(pass);
		
		driver.findElement(By.xpath("//button[@type='submit']")).click();
		
		String AR=driver.getTitle();
		String ER="OrangeHRM";
		
		soft=new SoftAssert();
		
		soft.assertEquals(AR, ER);
		
		
		
		
		//Assert.assertEquals(AR, ER,"Title not match");
		
		String AU=driver.getCurrentUrl();
		String EU="https://opensource-demo.orangehrmlive.com/web/index.php/dashboard";
		
		soft.assertEquals(AU, EU);
		soft.assertAll();
		//Assert.assertEquals(AU, EU);
		
}
}
