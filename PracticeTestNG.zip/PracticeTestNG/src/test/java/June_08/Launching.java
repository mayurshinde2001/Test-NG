package June_08;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

public class Launching {

	
	public WebDriver driver;
	
	
	@BeforeClass
	public void Launchbrowser() {
		
		
		
		Reporter.log("Open The Browser");
		driver=new ChromeDriver();
		driver.get("https://www.facebook.com/");
		driver.manage().window().maximize();
	}
	
	
	@AfterClass
	public void browserClose() {
		
		
		Reporter.log("Close The Browser");
		driver.close();
	}
}
