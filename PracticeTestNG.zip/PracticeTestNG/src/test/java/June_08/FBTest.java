package June_08;

import org.openqa.selenium.By;
import org.testng.Reporter;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class FBTest extends Launching{
	public SoftAssert soft;
	
	@Parameters({"username","pass"})
	@Test
	public void LoginFunctionality(String username, String pass) {
		
				
		
		Reporter.log("enter the username");
		driver.findElement(By.id("email")).sendKeys(username);
		
		
		Reporter.log("enter the password");
		driver.findElement(By.id("pass")).sendKeys(pass);
		
		
		Reporter.log("Click on login button");
		driver.findElement(By.name("login")).click();
		
		
		String Ar=driver.getTitle();
		
		String Er="Log in to Facebook";
		
		
		
		Reporter.log("Verify the result of title");
		soft=new SoftAssert();
		
		soft.assertEquals(Ar, Er);
		
		soft.assertAll();
	}
}
