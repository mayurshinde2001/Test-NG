package Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SaucedemoLogin {

	public WebDriver driver;
	
	public SaucedemoLogin(WebDriver driver) {
		
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(id= "user-name")
		private WebElement username;
	
	@FindBy(id = "password")
	private WebElement password;
	
	@FindBy(id = "login-button")
	private WebElement login;
	
	public String getTitle() {
	String title=driver.getTitle();
	return title;
	}

	public WebDriver getDriver() {
		return driver;
	}

	

	public WebElement getUsername() {
		return username;
	}

	

	public WebElement getPassword() {
		return password;
	}

	

	public WebElement getLogin() {
		return login;
	}

	
	
	
}
