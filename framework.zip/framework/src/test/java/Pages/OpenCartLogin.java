package Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class OpenCartLogin {

	public WebDriver driver;
	
	public OpenCartLogin(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(name = "firstname")
	private WebElement firstname;
	
	@FindBy(name = "lastname")
	private WebElement lastname;
	
	@FindBy(name= "email")
	private WebElement email;
	
	@FindBy(name = "password")
	private WebElement password;
	
	@FindBy(xpath = "//input[@id='input-newsletter-yes']")
	private WebElement radio;
	
	@FindBy(name = "agree")
	private WebElement checkbox;
	
	@FindBy(xpath= "//button[@type='submit']")
	private WebElement submit;

	
	
	
	public WebDriver getDriver() {
		return driver;
	}

	

	public WebElement getFirstname() {
		return firstname;
	}

	

	public WebElement getLastname() {
		return lastname;
	}

	

	public WebElement getEmail() {
		return email;
	}

	

	public WebElement getPassword() {
		return password;
	}

	

	public WebElement getRadio() {
		return radio;
	}

	

	public WebElement getCheckbox() {
		return checkbox;
	}

	

	public WebElement getSubmit() {
		return submit;
	}

	
	
	
	
	
}
