package Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class InstaLogin {

	public WebDriver driver;
	
	public  InstaLogin(WebDriver driver) {
		
		this.driver=driver;
		
		PageFactory.initElements(driver, this);
		
		
	}
	
	@FindBy(partialLinkText  = "Log in with Facebook")
	private WebElement text;
	
	@FindBy(name="email") 
	private WebElement username;
	
	@FindBy(name="pass")
	private WebElement password;
	
	@FindBy(name = "login")
	private WebElement login;

	public WebDriver getDriver() {
		return driver;
	}
	

	public String gettitle() {
		String title=driver.getTitle();
		
		return title;
		
	}

	public WebElement getLink() {
		return text;
	}
	

	public WebElement getUsername() {
		return username;
	}

	

	public WebElement getPassword() {
		return password;
	}

	

	public WebElement getLogin() {
		return login;
	}

	
	
	
	
}
