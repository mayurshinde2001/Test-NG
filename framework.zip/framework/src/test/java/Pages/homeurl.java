package Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class homeurl {

	public WebDriver driver;
	public homeurl(WebDriver driver) {
		
		
		this.driver=driver;
		
		PageFactory.initElements(driver, this);
	
	
	}
	public String geturl() {
		
		String URL=driver.getCurrentUrl();
		return URL;
		
	}
}
