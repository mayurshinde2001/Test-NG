package StepDefination;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import Pages.OpenCartLogin;
import Pages.homePage;
import io.cucumber.java.en.*;

public class openCartStepDef {

	public WebDriver driver;
	public OpenCartLogin log;
	public homePage home;
	
	@Given("user launch the browser")
	public void user_launch_the_browser() {
	    
		driver=new ChromeDriver();
	}

	@Given("enter the test url")
	public void enter_the_test_url() {
	    driver.get("https://demo.opencart.com/index.php?route=account/register&language=en-gb");
	    driver.manage().window().maximize();
	    
	}

	@When("^user enter the firstname as (.*)$")
	public void user_enter_the_firstname_as_firstname(String firstname) {
	    log=new OpenCartLogin(driver);
	    WebElement fname=log.getFirstname();
	    fname.sendKeys(firstname);
	}

	@When("^user enter the lastname as (.*)$")
	public void user_enter_the_lastname_as_lastname(String lastname) {
	    WebElement lname=log.getLastname();
	    lname.sendKeys(lastname);
	}

	@When("^user enter the email as (.*)$")
	public void user_enter_the_email_as_email(String email) {
	    WebElement mail=log.getEmail();
	    mail.sendKeys(email);
	}

	@When("^user enter the password as (.*)$")
	public void user_enter_the_password_as_password(String password) {
	   WebElement pass=log.getPassword();
	   pass.sendKeys(password);
	}

	@When("user click on a yes radio button")
	public void user_click_on_a_yes_radio_button(){
	   WebElement radios=log.getRadio();
	  
	   radios.click();
	}

	@When("user clcik on a checkbox")
	public void user_clcik_on_a_checkbox() throws InterruptedException {
	    WebElement check=log.getCheckbox();
	    Thread.sleep(2000);
	    check.click();
	}

	@When("user click on continue button")
	public void user_click_on_continue_button() {
	    WebElement submit=log.getSubmit();
	    submit.click();
	}

	@Then("register page display again")
	public void register_page_display_again() {
	    String title=home.getTitle();
	    System.out.println(title);
	}
}
