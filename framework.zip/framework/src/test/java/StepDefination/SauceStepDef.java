package StepDefination;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import Pages.SaucedemoLogin;
import io.cucumber.java.en.*;

public class SauceStepDef {

	public WebDriver driver;
	public SaucedemoLogin  log;
	
	@Given("User launch the browser")
	public void user_launch_the_browser() {
	    driver= new ChromeDriver();
	    driver.manage().window().maximize();
	}

	@Given("User enter the url")
	public void user_enter_the_url() {
	   driver.get("https://www.saucedemo.com/");
	}

	@When("^User enter the username as (.*)$")
	public void user_enter_the_username_as_username(String user) {
		log=new SaucedemoLogin(driver);
		WebElement name=log.getUsername();
		name.sendKeys(user);
	}

	@When("^User enter the password as (.*)$")
	public void user_enter_the_password_as_password(String pass) {
		WebElement word=log.getPassword();
		word.sendKeys(pass);
	}

	@When("user click on login button")
	public void user_click_on_login_button() {
		WebElement submit=log.getLogin();
		submit.click();
	}

	@Then("Homepage should be display")
	public void homepage_should_be_display() {
	String web=log.getTitle();
	System.out.println(web);
	}
}
