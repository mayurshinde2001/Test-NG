//package StepDefination;
//
//import io.cucumber.java.en.Given;
//import io.cucumber.java.en.Then;
//import io.cucumber.java.en.When;
//
//public class stepdef {
//
//
//@Given("user launch the chrome browser")
//public void user_launch_the_chrome_browser() {
//	
//	System.out.println("Launching done");
//}
//
//@Given("enter the test url {string}")
//public void enter_the_test_url(String string) {
//	System.out.println("Test URL done");
//}
//
//@When("user enter the username {string}")
//public void user_enter_the_username(String string) {
//	System.out.println("Username Enter");
//}
//
//@When("user enter the password {string}")
//public void user_enter_the_password(String string) {
//	System.out.println("Password Enter");
//}
//
//@When("click on login button")
//public void click_on_login_button() {
//	System.out.println("Login Button Clicked");
//}
//
//@Then("Home page should be display")
//public void home_page_should_be_display() {
//	System.out.println("Home page display");
//}
//}
