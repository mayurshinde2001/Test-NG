//package StepDefination;
//
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebElement;
//import org.openqa.selenium.chrome.ChromeDriver;
//
//import Pages.homePage;
//import Pages.homeurl;
//import Pages.HRMLogin;
//import io.cucumber.java.en.*;
//
//public class HrmStepDef {
//	
//	public HRMLogin log;
//	public WebDriver driver;
//	public homePage home;
//	public homeurl Url;
//
//	@Given("user launch the chrome browser")
//	public void user_launch_the_chrome_browser() {
//		
//		driver =new ChromeDriver();
//		
//		
//	}
//
//	@Given("enter the test url")
//	public void enter_the_test_url() {
//
//		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
//		
//		driver.manage().window().maximize();
//	}
//
////	@When("user enter the username")
////	public void user_enter_the_username() throws InterruptedException {
////		log=new HRMLogin(driver);
////		Thread.sleep(2000);
////		
////		WebElement username=log.getUsername();
////		username.sendKeys("Admin");
////	}
////
////	@When("user enter the password")
////	public void user_enter_the_password() throws InterruptedException {
////		Thread.sleep(2000);
////		
////		WebElement password=log.getPassword();
////		password.sendKeys("admin123");
////	}
//
//	
//	
//	@When("^user enter the username as (.*)$")
//	public void user_enter_the_username_as(String user) throws InterruptedException {
//		log=new HRMLogin(driver);
//		Thread.sleep(2000);
//		
//		WebElement username=log.getUsername();
//		username.sendKeys(user);
//	}
//
//	@When("^user enter the password as (.*)$")
//	public void user_enter_the_password_as(String pass) throws InterruptedException {
//		Thread.sleep(2000);
//		
//		WebElement password=log.getPassword();
//		password.sendKeys(pass);
//	}
//	
//	@When("click on login button")
//	public void click_on_login_button() throws InterruptedException {
//		
//		Thread.sleep(2000);
//		
//		WebElement login=log.getLogin();
//		login.click();;
//		
//	}
//
//	@Then("Home page should be display")
//	public void home_page_should_be_display() {
//		
//		home=new homePage(driver);
//		String title=home.getTitle();
//		String Expectedtitle="OrangeHRM";
//		
//		if(title.equalsIgnoreCase(Expectedtitle)) {
//			System.out.println("Test Case Passed....!!");
//		}
//		else {
//			System.out.println("Test Case Failed...!!!");
//		}
//	    
//	}
//	
//	@Then("should capture the url {string}")
//	public void should_capture_the_url(String string) {
//	    Url=new homeurl(driver);
//	    String url=Url.geturl();
//	    
//	    String ExURL="https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index";
//		
//	    if(url.equals(ExURL)) {
//	    	System.out.println("TEst Case pass..........!!!");
//	    }
//	    else {
//	    	System.out.println("Failed...!!!!");
//	    }
//	}
//
//
//	
//}
