//package StepDefination;
//
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebElement;
//import org.openqa.selenium.chrome.ChromeDriver;
//
//import Pages.InstaLogin;
//import io.cucumber.java.en.*;
//
//public class InstaStepDef {
//
//	public WebDriver driver;
//	public InstaLogin log;
//	
//	
//	@Given("User launch the chrome browser")
//	public void user_launch_the_chrome_browser() {
//	    driver=new ChromeDriver();
//	}
//
//	@Given("User enter the url")
//	public void user_enter_the_url() {
//	    
//		driver.get("https://www.instagram.com/");
//		driver.manage().window().maximize();
//	}
//	
//	@Given("User click on link")
//	public void user_click_on_link() throws InterruptedException {
//		log=new InstaLogin(driver);
//		Thread.sleep(2000);
//	    WebElement link=log.getLink();
//	    link.click();
//	}
//
//	@When("^user enter the username as (.*)$")
//	public void user_enter_the_username(String user) {
//	    
//		log=new InstaLogin(driver);
//		WebElement username=log.getUsername();
//		username.sendKeys(user);
//	}
//
//	@When("^user enter the password as (.*)$")
//	public void user_enter_the_password(String pass) {
//	   
//		WebElement password=log.getPassword();
//		password.sendKeys(pass);
//	}
//
//	@When("user click on login button")
//	public void user_click_on_login_button() {
//	  
//		WebElement login=log.getLogin();
//		login.click();
//	}
//
//	@Then("Insta homepage should be display")
//	public void insta_homepage_should_be_display() {
//	   
//		String title=log.gettitle();
//		String ER="Instagram";
//		
//		System.out.println(title);
//		if(title.equals(ER)) {
//			System.out.println("Test Case Passed....");
//		}
//		else {
//			System.out.println("Test Case Failed....");
//		}
//	}
//
//	
//
//}
